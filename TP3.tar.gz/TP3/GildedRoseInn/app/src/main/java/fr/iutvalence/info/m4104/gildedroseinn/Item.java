package fr.iutvalence.info.m4104.gildedroseinn;

public class Item {

	private static final int SELL_IN_DATE_THRESHOLD_FOR_BACKSTAGE_QUALITY_BEING_DECREMENTED_THREE_TIMES = 5;
	private static final int SELL_IN_DATE_THRESHOLD_FOR_BACKSTAGE_QUALITY_BEING_DECREMENTED_TWICE = 10;

    private final String name;

	private int sellIn;

	private int quality;

	public Item(String name, int quality, int sellIn)
	{
		this.name = name;
		this.sellIn = sellIn;
		this.setQuality(quality);
	}

	public void update()
	{
		updateItemSellIn();
		updateItemQuality();
	}

	protected void updateItemSellIn()
	{
		decrementItemSellIn();
	}

	protected void updateItemQuality()
	{
		updateNormalItemQuality();
	}

	protected void updateBackstageItemQuality()
	{
		if (hasItemSellInDatePassed())
		{
			this.setQuality(0);
			return;
		}

		decrementItemQualityIfNotZero();
		if (this.getSellIn() <= SELL_IN_DATE_THRESHOLD_FOR_BACKSTAGE_QUALITY_BEING_DECREMENTED_TWICE)
			decrementItemQualityIfNotZero();
		if (this.getSellIn() <= SELL_IN_DATE_THRESHOLD_FOR_BACKSTAGE_QUALITY_BEING_DECREMENTED_THREE_TIMES)
			decrementItemQualityIfNotZero();
	}

	protected void updateNormalItemQuality()
	{
		decrementItemQualityIfNotZero();
		if (hasItemSellInDatePassed())
			decrementItemQualityIfNotZero();
	}

	protected void updateAgedBrieItemQuality()
	{
		incrementItemQualityIfNotFifty();
	}

	protected void incrementItemQualityIfNotFifty()
	{
		if (this.getQuality() < 50)
			incrementItemQuality();
	}

	protected void incrementItemQuality()
	{
		this.setQuality(this.getQuality() + 1);
	}

	protected void decrementItemQualityIfNotZero()
	{
		if (this.getQuality() > 0)
			decrementItemQuality();
	}

	protected boolean hasItemSellInDatePassed()
	{
		return this.getSellIn() <= 0;
	}

	protected void decrementItemSellIn()
	{
		this.setSellIn(this.getSellIn() - 1);
	}

	protected void decrementItemQuality()
	{
		this.setQuality(this.getQuality() - 1);
	}

	public String getName()
	{
		return this.name;
	}

	public void setSellIn(int sellIn)
	{
		this.sellIn = sellIn;
	}

	public int getSellIn()
	{
		return this.sellIn;
	}

	public int getQuality()
	{
		return quality;
	}

	public void setQuality(int quality)
	{
		this.quality = quality;
	}
}

