package fr.iutvalence.info.m4104.gildedroseinn;

import android.content.Context;
import android.database.DataSetObserver;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.TextView;

import org.w3c.dom.Text;

/**
 * L'implémentation de la classe Adapter, plus particulièrement ListAdapter qui va permettre de remplir la listView d'items
 */
public class DisplayListItem implements ListAdapter {

    private final Information app;
    private final Context context;
    private final boolean onShop; // attribut permettant de travailler soit sur la liste de l'inventaire soit sur la liste d'items du shop

    public DisplayListItem(Information app, Context shopActivity,boolean onShop)
    {
        this.app = app;
        this.context = shopActivity;
        this.onShop = onShop;
    }

    @Override
    public boolean areAllItemsEnabled() {
        return true;
    }

    @Override
    public boolean isEnabled(int position) {
        return true;
    }

    @Override
    public void registerDataSetObserver(DataSetObserver observer) {

    }

    @Override
    public void unregisterDataSetObserver(DataSetObserver observer) {

    }

    @Override
    public int getCount()
    {
        if(onShop)
            return app.shopitem.size();
        return app.inventoryitem.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

		// La méthode permettant de récupérer les références et remplir la listView en retournant la View correspondante au composant de l'item
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (onShop)
        {
            LayoutInflater li = LayoutInflater.from(context);
            convertView = li.inflate(R.layout.list_shop_layout, parent, false);

            TextView itemName = (TextView) convertView.findViewById(R.id.shopItem);
            itemName.setText(app.shopitem.get(position).getName());

            TextView shopSellIn = (TextView) convertView.findViewById(R.id.shopSellIn);
            shopSellIn.setText("" + app.shopitem.get(position).getSellIn());

            TextView shopQuality = (TextView) convertView.findViewById(R.id.shopQuality);
            shopQuality.setText("" + app.shopitem.get(position).getQuality());

            return convertView;
        }
        else
        {
            LayoutInflater li = LayoutInflater.from(context);
            convertView = li.inflate(R.layout.list_inventory_item, parent, false);

            TextView itemName = (TextView) convertView.findViewById(R.id.itemInventory);
            itemName.setText(app.inventoryitem.get(position).getName());

            TextView inventoryQuality = (TextView) convertView.findViewById(R.id.qualityInventory);
            inventoryQuality.setText("" + app.inventoryitem.get(position).getQuality());

            TextView sellinInventory = (TextView) convertView.findViewById(R.id.valeurInventory);
            sellinInventory.setText("" + app.inventoryitem.get(position).getSellIn());

            return convertView;
        }


    }

    @Override
    public int getItemViewType(int position) {
        return 0;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public boolean isEmpty() {
        return false;
    }
}
