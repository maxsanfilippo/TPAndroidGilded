package fr.iutvalence.info.m4104.gildedroseinn;

import android.app.Application;

import java.util.ArrayList;
import java.util.List;

/**
 * Classe Application de l'application, contenant les listes manipulées et des méthodes appelées par les différentes activités
 */
public class Information extends Application
{
    List<Item> shopitem;
    List<Item> inventoryitem;
    int monnaie;
    int day;

    public Information()
    {
        super();
        inventoryitem = new ArrayList<Item>();
        shopitem = new ArrayList<Item>();
        shopitem.add(new ItemDexterityVest("+5 Dexterity Vest", 10, 20));
        shopitem.add(new ItemAgedBrie("Aged Brie", 2, 0));
        shopitem.add(new ItemElixirOfTheMongoose("Elixir of the Mongoose", 5, 7));
        shopitem.add(new ItemSulfuras("Sulfuras, Hand of Ragnaros", 0, 80));
        shopitem.add(new ItemSulfuras("Sulfuras, Hand of Ragnaros", -1, 80));
        shopitem.add(new ItemBackstage("Backstage passes to a TAFKAL80ETC concert", 15, 20));
        shopitem.add(new ItemBackstage("Backstage passes to a TAFKAL80ETC concert", 10, 49));
        shopitem.add(new ItemBackstage("Backstage passes to a TAFKAL80ETC concert", 5, 49));
        shopitem.add(new ItemConjuredManaCake("Conjured Mana Cake", 3, 6));
        day = 0;
    }
	// lors d'un changement de jour l'argent en poche augmente de 10
    public void nextDay()
    {
        day++;
        for(int i = 0; i < inventoryitem.size(); i++)
        {
            GildedRose.updateItem(inventoryitem.get(i));
        }

        for(int i = 0; i < shopitem.size(); i++)
        {
            GildedRose.updateItem(shopitem.get(i));
        }

        // argent de poche
        monnaie = monnaie + 10;
    }

    public void setCash(int cash)
    {
        monnaie = cash;
    }
	// Lors de l'achat d'un objet, on ajoute l'item séléectionné dans la liste de l'inventaire,  cela coute de l'argent ( tous les items coutent 5$)
    public boolean buy(Item item)
    {
        if (monnaie>=5)
        {
            inventoryitem.add(item);
            monnaie = monnaie -5;
            return true;
        }
        return false;
    }
	// Lorsqu'un item est utilisé dans l'inventaire, on le supprime simplément de la liste
    public void use(Item item) {inventoryitem.remove(item);}



}
