package fr.iutvalence.info.m4104.gildedroseinn;

/**
 * Created by Laeti on 21/02/2016. Classe de l'item ItemAgedBrie, car comportement particulier
 */
public class ItemAgedBrie extends Item {
    public ItemAgedBrie(String name, int sellIn, int quality) {
        super(name, sellIn, quality);
    }

    protected void updateItemQuality()
    {
        super.updateAgedBrieItemQuality();
    }
}
