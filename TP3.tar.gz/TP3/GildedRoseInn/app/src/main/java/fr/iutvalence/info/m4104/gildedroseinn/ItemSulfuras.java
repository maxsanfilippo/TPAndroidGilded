package fr.iutvalence.info.m4104.gildedroseinn;

/**
 * Created by Laeti on 21/02/2016.
 */
public class ItemSulfuras extends Item {

    public ItemSulfuras(String name, int sellIn, int quality) {
        super(name, sellIn, quality);
    }

    protected void updateItemSellIn()
    {

    }

    protected void updateItemQuality()
    {

    }

}
