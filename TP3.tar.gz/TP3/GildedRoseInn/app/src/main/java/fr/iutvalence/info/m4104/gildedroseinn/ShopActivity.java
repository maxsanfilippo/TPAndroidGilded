package fr.iutvalence.info.m4104.gildedroseinn;

import android.content.Context;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

	// Activité correspondant au shop contenant une listeView contenant les items du magasin
public class ShopActivity extends ActionBarActivity {
    ListView mListView;
    Information app;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        app = (Information) getApplication();
        setContentView(R.layout.shop_layout);
        mListView = (ListView) findViewById(R.id.listView);
	// Lors de la sélection d'un item, il est acheté si les fonds sont présents
        DisplayListItem adapter = new DisplayListItem(app,this,true);
        mListView.setAdapter(adapter);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                Item item = app.shopitem.get(position);
                Context context = getApplicationContext();
	// On vérifie si on possède l'argent nécessaire pour acheter l'item ( la méthode buy() renvoie un booléen selon la bonne réussite de l'opération )
                if (app.buy(item))
                {
	// On indique au client l'objet qu'il a acheté
                    CharSequence text = "You just bought " + item.getName().toString() + " at the price of 5$!!";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();

                }
                else {
	// si l'achat n'a pas pu être effectué, cela veut dire qu'il n'avait pas l'argent nécessaire et on lui indique donc 
                    CharSequence text = "You don't have the necessary money to buy : " + item.getName().toString() + " :/ !";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                }

            }
        });
    }

}
