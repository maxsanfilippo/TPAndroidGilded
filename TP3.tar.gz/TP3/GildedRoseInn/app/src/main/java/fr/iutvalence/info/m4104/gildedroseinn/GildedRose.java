package fr.iutvalence.info.m4104.gildedroseinn;

public class GildedRose
{
    public static void updateItem(Item item)
    {
        item.update();
    }
}

