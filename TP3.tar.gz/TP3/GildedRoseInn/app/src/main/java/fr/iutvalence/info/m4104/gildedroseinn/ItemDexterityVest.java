package fr.iutvalence.info.m4104.gildedroseinn;

/**
 * Created by Laeti on 21/02/2016.
 */
public class ItemDexterityVest extends Item {
    public ItemDexterityVest(String name, int sellIn, int quality) {
        super(name, sellIn, quality);
    }

}
