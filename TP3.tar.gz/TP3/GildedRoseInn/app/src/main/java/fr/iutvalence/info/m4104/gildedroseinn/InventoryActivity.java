package fr.iutvalence.info.m4104.gildedroseinn;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

// Activity de l'inventaire contenant une listeview d'items
public class InventoryActivity extends Activity {

    private Information app;
    private ListView mListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inventory_layout);
        app = (Information) getApplication();
        mListView = (ListView) findViewById(R.id.listViewInventory);
        DisplayListItem adapter = new DisplayListItem(app,this,false);

	// Si on sélectionne un item, il est utilisé ( = supprimé de la liste )
        mListView.setAdapter(adapter);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Item item = app.inventoryitem.get(position);
                app.use(item);

                Context context = getApplicationContext();
	// Petit affichage indicatif sur l'utilisation de l'item susdit
                CharSequence text = "You just used" + item.getName() + " !!";
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(context, text, duration);
                toast.show();

                mListView.invalidateViews(); // refresh

            }
        });
    }
}
