package fr.iutvalence.info.m4104.gildedroseinn;

import android.app.Activity;
import android.app.Application;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class HomeActivity extends Activity {

    Information app;
    TextView day;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        app = (Information) getApplication();
	// On récupère l'argent stocké au démarrage de l'application, avec une valeure par défaut ( au cas ou, et de toute façon on a pas le choix )
        SharedPreferences settings = getSharedPreferences("myset",0);
        int monney = settings.getInt("cashInThePocket", 50);
        app.setCash(monney);
        setContentView(R.layout.home_layout);
        updateCashDisplay();
    }
    public void homeActivityClickListener(View view)
    {
        switch (view.getId())
        {
            case R.id.shop_button :
                startShopActivity();
                break;
            case R.id.inventory_button :
                startInventoryActivity();
                break;
            case R.id.next_button :
                app.nextDay();
                day = (TextView) findViewById(R.id.day_text);
                day.setText("Day " + app.day);
                updateCashDisplay();
                break;
            default :
        }
    }
	// on redéfinit onResume pour permettre l'update de l'argent lorsqu'on se déplace d'activité ( shop et inventory)
    protected void onResume()
    {
        super.onResume();
        updateCashDisplay();
    }
	// méthode permettant de mettre à jour l'argent, appelée lors du changement de jour et onResume de l'activité
    public void updateCashDisplay()
    {
        TextView monnay = (TextView) findViewById(R.id.Monney);
        String monny = String.valueOf(app.monnaie);
        monnay.setText(monny);
    }

    private void startInventoryActivity()
    {
        this.startActivity(new Intent(this, InventoryActivity.class));
    }


    private void startShopActivity()
    {
        this.startActivity( new Intent(this, ShopActivity.class));
    }

    protected void onStop()
    {
        super.onStop();
		// On stock à la fermeture de l'application la monnaire courante, update ensuite lorsque l'application se lance
        SharedPreferences settings = getSharedPreferences("myset", 0);
        SharedPreferences.Editor editor = settings.edit();
        editor.putInt("cashInThePocket",app.monnaie);
        editor.commit();
    }
}
